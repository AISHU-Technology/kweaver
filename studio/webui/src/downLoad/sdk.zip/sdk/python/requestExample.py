#!/usr/bin/env python
# -*- coding:utf-8 -*-

import requests
import utils.shareAPI as shareAPI
import urllib
import json
import time

urlBase = "https://10.4.71.183:443"
sf = shareAPI.shareAPI()


def getAppid():
    username = "admin"
    userpass = "95790df44d8ac8b12fb2a8d9fc65a692"
    payload = {"name": username, "pass": userpass}
    urlAppId = urlBase + "/api/manager/v1/appid"
    response = requests.post(urlAppId, verify=False, data=json.dumps(payload))
    result = response.json()
    appid = result["res"]["AppId"]
    return appid


def openApiGetKG():
    # 基本参数
    appid = getAppid()
    timestamp = time.time()
    timestampString = "{0}".format(timestamp).split(".")[0]
    urlCode = "page=1&size=2"

    # 如果是 get请求，parmString只包含 url
    appkey = sf.getAppKey(appid, paramString=urlCode, timestamp=timestampString)
    header = {"appid": appid, "appkey": appkey, "timestamp": timestampString}

    # 取消证书验证
    # true
    urlOpen = urlBase + "/api/engine/v1/open/kg"
    # false
    # urlOpen = urlBase + "/api/engine/v1/open/?page=1&size=2"
    response = requests.get(urlOpen, verify=False, headers=header, params=urlCode)
    print(response.content)


def openApiGetKGId():
    # 基本参数
    appid = getAppid()
    timestamp = time.time()
    timestampString = "{0}".format(timestamp).split(".")[0]
    urlCode = "query=电工&page=1&size=2"

    # 如果是 get请求，parmString只包含 url
    appkey = sf.getAppKey(appid, paramString=urlCode, timestamp=timestampString)
    header = {"appid": appid, "appkey": appkey, "timestamp": timestampString}

    # 取消证书验证
    urlOpen = urlBase + "/api/engine/v1/open/kg/1"
    response = requests.get(urlOpen, verify=False, headers=header, params=urlCode)
    print(response.content)


def openApiGetExploreId():
    # 基本参数
    appid = getAppid()
    timestamp = time.time()
    timestampString = "{0}".format(timestamp).split(".")[0]
    urlCode = "io=1&page=1&size=1&class=1&rid=1"

    # 如果是 get请求，parmString只包含 url
    appkey = sf.getAppKey(appid, paramString=urlCode, timestamp=timestampString)
    print(appkey)
    header = {"appid": appid, "appkey": appkey, "timestamp": timestampString}

    # 取消证书验证
    urlOpen = urlBase + "/api/engine/v1/open/explore/1/expande"
    response = requests.get(urlOpen, verify=False, headers=header, params=urlCode)
    print(response.content)


def openApiGetExploreSearche():
    # 基本参数
    appid = getAppid()
    timestamp = time.time()
    timestampString = "{0}".format(timestamp).split(".")[0]
    urlCode = "io=1&page=1&size=1&class=1&rid=1"

    # 如果是 get请求，parmString只包含 url
    appkey = sf.getAppKey(appid, paramString=urlCode, timestamp=timestampString)
    print(appkey)
    header = {"appid": appid, "appkey": appkey, "timestamp": timestampString}

    # 取消证书验证
    urlOpen = urlBase + "/api/engine/v1/open/explore/1/searche"
    response = requests.get(urlOpen, verify=False, headers=header, params=urlCode)
    print(response.content)


def openApiGetExploreExpande():
    # 基本参数
    appid = getAppid()
    timestamp = time.time()
    timestampString = "{0}".format(timestamp).split(".")[0]
    urlCode = "io=1&page=1&size=1&class=1&rid=1"

    # 如果是 get请求，parmString只包含 url
    appkey = sf.getAppKey(appid, paramString=urlCode, timestamp=timestampString)
    print(appkey)
    header = {"appid": appid, "appkey": appkey, "timestamp": timestampString}

    # 取消证书验证
    urlOpen = urlBase + "/api/engine/v1/open/explore/1/expande"
    response = requests.get(urlOpen, verify=False, headers=header, params=urlCode)
    print(response.content)


def openApiGetAdvSearch():
    # 基本参数
    appid = getAppid()
    timestamp = time.time()
    timestampString = "{0}".format(timestamp).split(".")[0]
    print(timestampString)
    urlCode = "query=电工&page=1&size=2"

    # 如果是 get请求，parmString只包含 url
    appkey = sf.getAppKey(appid, paramString=urlCode, timestamp=timestampString)
    header = {"appid": appid, "appkey": appkey, "timestamp": timestampString}

    # 取消证书验证
    urlOpen = urlBase + "/api/engine/v1/open/adv-search"
    response = requests.get(urlOpen, verify=False, headers=header, params=urlCode)
    print(response.content)


def openApiGetKCVertex():
    # 基本参数
    appid = getAppid()
    timestamp = time.time()
    timestampString = "{0}".format(timestamp).split(".")[0]
    urlCode = "kgid=1&class=topic&condition=name=['bookmark']"

    # 如果是 get请求，parmString只包含 url
    appkey = sf.getAppKey(appid, paramString=urlCode, timestamp=timestampString)
    header = {"appid": appid, "appkey": appkey, "timestamp": timestampString}

    # 取消证书验证
    urlOpen = urlBase + "/api/engine/v1/open/kc/vertex"
    response = requests.get(urlOpen, verify=False, headers=header, params=urlCode)
    print(response.content)


def openApiPostKCVertex():
    # 基本参数
    appid = getAppid()
    timestamp = time.time()
    timestampString = "{0}".format(timestamp).split(".")[0]
    payload = {"kgid": 11, "class": "desc", "fields": "abc", "name": "abc"}

    # 如果是 post 请求，parmString 只包含 body
    appkey = sf.getAppKey(appid, paramString=json.dumps(payload), timestamp=timestampString)
    header = {"appid": appid, "appkey": appkey, "timestamp": timestampString}

    # 取消证书验证
    urlOpenKG = urlBase + "/api/engine/v1/open/kc/vertex"
    response = requests.post(urlOpenKG, verify=False, headers=header, data=json.dumps(payload))
    print(response.content)


def openApiPostKCDocRecommend():
    # 基本参数
    appid = getAppid()
    timestamp = time.time()
    timestampString = "{0}".format(timestamp).split(".")[0]
    print(timestampString)
    payload = {"kgid": 11, "page": 1, "size": 1, "profile": [1, 2]}

    # 如果是 post 请求，parmString 只包含 body
    appkey = sf.getAppKey(appid, paramString=json.dumps(payload).encode("utf-8"), timestamp=timestampString)
    header = {"appid": appid, "appkey": appkey, "timestamp": timestampString}

    # 取消证书验证
    urlOpenKG = urlBase + "/api/engine/v1/open/kc/doc/recommend"
    response = requests.post(urlOpenKG, verify=False, headers=header, data=json.dumps(payload))
    print(response.content)


def openApiPostV1explore():
    # 基本参数
    appid = getAppid()
    timestamp = time.time()
    timestampString = "{0}".format(timestamp).split(".")[0]
    print(timestampString)
    param = """
    query {
        kglist(page:-1) {
            count
            kglist {
                id
                name
            }
        }
    }
    """
    payload = {"query": param}

    params = """{"query":"query {\r\n        kglist(page:-1) {\r\n            count\r\n            kglist {\r\n                id\r\n                name\r\n            }\r\n        }\r\n    }","variables":{}}"""

    # 如果是 post 请求，parmString 只包含 body
    print("parmString: {0}".format(json.dumps(payload).encode("utf-8")))
    appkey = sf.getAppKey(appid, paramString=params.encode("utf-8"), timestamp=timestampString)
    header = {"appid": appid, "appkey": appkey, "timestamp": timestampString}

    # 取消证书验证
    urlOpenKG = urlBase + "/api/engine/v1/open/explore"
    response = requests.post(urlOpenKG, verify=False, headers=header, data=params)
    print(response.content)


if __name__ == '__main__':
    openApiGetKG()
