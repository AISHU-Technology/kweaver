#!/usr/bin/env python
# -*- coding:utf-8 -*-

# describe: 用于生成 appkey 进行图谱校验

import hashlib
import hmac
import base64


class shareAPI():

    def getAppKey(self, appid, paramString, timestamp):
        """
        :param appid: 账户appid
        :param reqParams: 请求参数
        :param timestamp: 10位时间戳
        :return:
        """
        _timestamp = hashlib.sha256(str(timestamp).encode("utf-8")).digest().hex().encode("utf-8")
        _reqParams = hashlib.sha256(paramString.encode("utf-8")).digest().hex().encode("utf-8")
        shaStr = hmac.new(appid.encode("utf-8"), _timestamp + _reqParams, digestmod=hashlib.sha256).digest()
        return base64.b64encode(shaStr.hex().encode("utf-8"))
