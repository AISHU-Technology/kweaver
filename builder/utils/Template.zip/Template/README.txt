*********词库模板格式说明**********

1、上传文件格式仅支持TXT和CSV；

2、具体格式规范：
	1) 第一行为列名，表示该列数据索引名称，名称字符只支持数字、字母、下划线，且最大长度为50字符；
	2) 第二行之后为词汇数据，单个词汇不可为空，最大长度为50字符；
	3) 最多支持5列数据；
	4) 每行数据之间以\t间隔；
	5) 文件编码为utf-8，避免读取错误；
	6) 文件大小不超过10MB，且行数不超过350000行；
	7) 请按照规范要求，上传词库数据；


此文件为说词库模板明文件，具体词汇数据请按照此规范即可。



*********Description of lexicon template format**********

1、Uploading files only supports TXT and CSV；

2、Detailed format specification：
	1) The first row is the column name, representing the data index name of the column. The name characters only support numbers, letters, and underscores, and the maximum length is 50 characters;
	2) The second line and the following are vocabulary data. A single vocabulary cannot be empty, and the maximum length is 50 characters;
	3) Up to 5 columns are supported;
	4) The terms of each line of data in the txt file are separated by \t;
	5) The document code is UTF-8;
	6) The file size shall not exceed 10M and the number of lines shall not exceed 350000;
	7) Please upload lexicon data according to the specification requirements;

This file is the description file of lexicon template. Please follow the word specification for detailed vocabulary data.







