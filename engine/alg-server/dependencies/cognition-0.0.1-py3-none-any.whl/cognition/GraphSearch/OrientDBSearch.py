# !/usr/bin/env python
# -*- coding:utf-8 -*-
from .GraphSearch import GraphSearch


class OrientDBSearch(GraphSearch):
    """
    GraphSearch中的方法在此都要实现一遍
    """
    pass
